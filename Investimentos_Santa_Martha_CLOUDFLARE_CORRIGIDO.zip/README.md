# Investimentos Santa Martha — Cloudflare

Projeto estático preparado para Cloudflare Workers Static Assets.

## Deploy
Use no Cloudflare:

npx wrangler deploy

O `index.html`, manifest, service worker e ícones ficam na raiz do repositório. O `wrangler.jsonc` aponta `assets.directory` para `.` para evitar erro de pasta estática ausente.
