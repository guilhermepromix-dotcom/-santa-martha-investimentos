# Investimentos Santa Martha

Aplicativo web/PWA estático para controle dos investimentos do Santa Martha Supermercado.

## Cloudflare Workers (GitHub)
- Build command: deixe vazio / sem comando de build.
- Deploy command: `npx wrangler deploy`
- Root directory: `/` (raiz do repositório).

O Wrangler publica automaticamente a pasta `public` definida em `wrangler.jsonc`.

## Dados
Os investimentos ficam salvos no `localStorage` do navegador/dispositivo. Limpar os dados do site/navegador remove esses registros.
