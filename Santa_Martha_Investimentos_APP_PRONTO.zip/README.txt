SANTA MARTHA INVESTIMENTOS
Estrutura pronta para Cloudflare Workers Static Assets.

IMPORTANTE:
1. Descompacte este ZIP.
2. No GitHub, envie OS ITENS DE DENTRO desta pasta, não o ZIP fechado.
3. Na raiz do repositório devem aparecer:
   public/
   package.json
   wrangler.jsonc
4. No Cloudflare, comando de implantação: npm run deploy
